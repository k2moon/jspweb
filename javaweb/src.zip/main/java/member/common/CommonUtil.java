package member.common;

public class CommonUtil {
	public final static int listNum = 15;
	public final static int blockNum = 10;
	
}
